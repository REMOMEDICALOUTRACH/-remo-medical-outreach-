# Add Event Pages - Remo Medical Outreach

## How to Upload

1️⃣ Go to your GitHub repo: https://github.com/remo-medical-outreach/remo-medical-outreach  
2️⃣ Click **Add file → Upload files**.  
3️⃣ Upload everything from this zip:
   - `/pages/event.js`
   - `/pages/event-register.js`
   - `/pages/thank-you.js`
   - `/public/downloads/SPECIAL_INVITE.png`
4️⃣ Commit changes → Vercel auto-deploys.
5️⃣ Test live:
   - https://remomedicaloutreach.org/event
   - https://remomedicaloutreach.org/event-register
   - https://remomedicaloutreach.org/thank-you

Nothing from your existing site will be replaced.
