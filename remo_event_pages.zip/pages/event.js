import Nav from "../components/Nav";
import Footer from "../components/Footer";

export default function EventPage() {
  return (
    <>
      <Nav />
      <main className="bg-white text-gray-800">
        <section className="relative bg-red-700 text-white py-16 px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-4 uppercase">
              1st Remo Public Health & Industrial Accountability Colloquium
            </h1>
            <p className="text-lg">
              Safeguarding Community Health: Strengthening Corporate and Government Accountability on Industrial Effluent Discharge
            </p>
            <p className="mt-4 text-yellow-300 font-semibold">
              📅 Wednesday, 19th November 2025 • 12 Noon  
              📍 The Innova Place, Obafemi Awolowo Ave, GRA Quarters, Off Oba Erinwole Road, Sagamu, Ogun State
            </p>
          </div>
        </section>

        <section className="max-w-5xl mx-auto px-6 py-12">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img
                src="/downloads/SPECIAL_INVITE.png"
                alt="Remo Medical Outreach Event"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-red-700 mb-4">About the Event</h2>
              <p className="mb-4">
                This colloquium brings together industry leaders, CEOs, senior managers,
                and government stakeholders to discuss and strengthen environmental health
                accountability in Remo communities.
              </p>
              <p className="mb-4">
                Join us as we explore strategies for reducing industrial pollution,
                safeguarding public health, and promoting sustainable corporate practices.
              </p>
              <p className="font-semibold">Convener: <span className="text-red-700">Remo Medical Outreach (RMO)</span></p>
            </div>
          </div>
        </section>

        <section className="text-center py-16 bg-gray-50">
          <h2 className="text-3xl font-bold text-red-700 mb-4">
            Confirm Your Attendance
          </h2>
          <p className="mb-6 text-gray-700">
            Registration is free but required for planning purposes.
          </p>
          <a
            href="/event-register"
            className="bg-red-700 text-white px-8 py-3 rounded-full shadow-lg hover:bg-red-800 transition"
          >
            Register Now
          </a>
        </section>

        <section className="text-center py-8">
          <p className="text-gray-600">
            📞 RSVP: <span className="text-red-700 font-semibold">08135165692, 08022302230</span>
          </p>
        </section>
      </main>
      <Footer />
    </>
  );
}
