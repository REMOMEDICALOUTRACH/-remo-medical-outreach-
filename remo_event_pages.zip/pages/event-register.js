import Nav from "../components/Nav";
import Footer from "../components/Footer";

export default function EventRegister() {
  return (
    <>
      <Nav />
      <main className="bg-white text-gray-800">
        <section className="bg-red-700 text-white py-16 px-6 text-center">
          <h1 className="text-4xl font-bold uppercase mb-4">
            Register for the 1st Remo Public Health & Industrial Accountability Colloquium
          </h1>
          <p className="text-lg max-w-2xl mx-auto">
            Join CEOs, Senior Managers, and Government Leaders as we strengthen
            accountability for industrial effluent discharge and community health.
          </p>
          <p className="mt-4 text-yellow-300 font-semibold">
            📅 Wednesday, 19th November 2025 • 🕛 12 Noon  
            📍 The Innova Place, Obafemi Awolowo Ave, Sagamu, Ogun State
          </p>
        </section>

        <section className="max-w-3xl mx-auto px-6 py-12">
          <h2 className="text-2xl font-bold text-red-700 text-center mb-6">
            Attendance Registration Form
          </h2>

          <form
            action="https://formspree.io/f/mvgpylvp"
            method="POST"
            className="space-y-6 bg-gray-50 p-8 rounded-lg shadow-md"
          >
            <input type="hidden" name="_next" value="https://remomedicaloutreach.org/thank-you" />

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Full Name *</label>
              <input type="text" name="name" required className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600" />
            </div>

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Organization / Company *</label>
              <input type="text" name="organization" required className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600" />
            </div>

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Position / Title</label>
              <input type="text" name="position" className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600" />
            </div>

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Email Address *</label>
              <input type="email" name="email" required className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600" />
            </div>

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Phone Number *</label>
              <input type="tel" name="phone" required className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600" />
            </div>

            <div>
              <label className="block mb-2 font-semibold text-gray-700">Would you like to receive future updates from RMO?</label>
              <select name="updates" className="w-full border border-gray-300 p-3 rounded focus:ring-2 focus:ring-red-600">
                <option value="Yes">Yes, keep me informed</option>
                <option value="No">No, thank you</option>
              </select>
            </div>

            <button type="submit" className="w-full bg-red-700 text-white py-3 rounded-lg font-semibold text-lg hover:bg-red-800 transition">
              Submit Registration
            </button>
          </form>

          <p className="text-center text-gray-600 text-sm mt-4">
            🔒 Your information is secure and will only be used for event coordination.
          </p>
        </section>
      </main>
      <Footer />
    </>
  );
}
