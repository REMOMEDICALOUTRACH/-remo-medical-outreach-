import Nav from "../components/Nav";
import Footer from "../components/Footer";

export default function ThankYou() {
  return (
    <>
      <Nav />
      <main className="bg-white text-gray-800">
        <section className="bg-red-700 text-white py-20 px-6 text-center">
          <h1 className="text-4xl font-bold mb-4">🎉 Thank You for Registering!</h1>
          <p className="text-lg max-w-2xl mx-auto">
            Your registration for the <strong>1st Remo Public Health & Industrial Accountability Colloquium</strong> has been received successfully.
          </p>
        </section>

        <section className="max-w-3xl mx-auto px-6 py-12 text-center">
          <p className="text-gray-700 mb-6">
            We look forward to seeing you at the event!
          </p>

          <div className="border-l-4 border-red-600 bg-gray-50 p-6 rounded-lg shadow text-left">
            <p className="text-gray-800 mb-2">📅 <strong>Date:</strong> Wednesday, 19th November 2025</p>
            <p className="text-gray-800 mb-2">🕛 <strong>Time:</strong> 12 Noon</p>
            <p className="text-gray-800 mb-2">📍 <strong>Venue:</strong> The Innova Place, Obafemi Awolowo Ave, GRA Quarters, Off Oba Erinwole Road, Sagamu, Ogun State.</p>
            <p className="text-gray-800">📞 <strong>RSVP:</strong> 08135165692 | 08022302230</p>
          </div>

          <p className="mt-8 text-gray-600">
            A confirmation email will be sent to you shortly. Please check your inbox (and spam folder, just in case).
          </p>

          <div className="mt-10 flex flex-col md:flex-row justify-center gap-4">
            <a href="/downloads/SPECIAL_INVITE.png" download="Remo_Colloquium_Invite.png" className="bg-red-700 text-white px-8 py-3 rounded-full font-semibold hover:bg-red-800 transition">
              📥 Download Event Flyer
            </a>

            <a href="/" className="bg-gray-200 text-gray-800 px-8 py-3 rounded-full font-semibold hover:bg-gray-300 transition">
              ⬅ Return to Homepage
            </a>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
